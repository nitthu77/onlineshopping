export class Cart {
    id:number=0;
    customer_id:number=0;
    product_id:number=0;
    price:number=0;
}
