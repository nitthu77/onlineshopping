import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './pages/login/login.component';

import { SignupComponent } from './pages/signup/signup.component';
import { CartComponent } from './pages/cart/cart.component';
import { NavigationComponent } from './pages/navigation/navigation.component';
import { BookComponent } from './pages/book/book.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LogoutComponent } from './pages/logout/logout.component';
import { ProductComponent } from './pages/product/product.component';
import { ElectronicsComponent } from './pages/electronics/electronics.component';
import { ClothingComponent } from './pages/clothing/clothing.component';
import { FooterComponent } from './pages/footer/footer.component';
import { SlideComponent } from './pages/slide/slide.component';
import { OrderplacedComponent } from './pages/orderplaced/orderplaced.component';
import { PaymentComponent } from './pages/payment/payment.component';
import { OrderComponent } from './pages/order/order.component';
import { ProfileComponent } from './profile/profile.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    CartComponent,
    NavigationComponent,
    BookComponent,
    LogoutComponent,
    ProductComponent,
    CartComponent,
    ClothingComponent,
    ElectronicsComponent,
    PaymentComponent,
    FooterComponent,
    SlideComponent,
    OrderplacedComponent,
    OrderComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
