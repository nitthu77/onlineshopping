export class Customer {

    id:number=0;
	firstName:string="";
	lastName:string="";
	password:string="";
	mobile:string="";
	email:string="";
	role:string="";
	address:string="";
}
