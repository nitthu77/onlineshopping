import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:any;
  str:any;
  constructor(private fb:FormBuilder, private cs:CustomerService,private router:Router) {
    this.loginForm=this.fb.group({
      id:['',[Validators.required]],
      password:['',[Validators.required, Validators.minLength(5), Validators.maxLength(15)]]
    });
   }
  
  ngOnInit(): void {
  }

  get f()
  {
    return this.loginForm.controls;
  }
  fnLogin()
  {    
    var id=this.loginForm.controls['id'].value;
    var pwd=this.loginForm.controls['password'].value;
     //alert(id+" : "+pwd);
    this.cs.findCustomerByIdPassword(id, pwd).subscribe(data=>{
      console.log(data);

      //this.cs.loginStatus();
      if(data!=null)
      {
        //var customer:any;
        //customer=data;
        localStorage.setItem("customer",JSON.stringify(data));
        this.str=localStorage.getItem("customer");
        var customer=JSON.parse(this.str);
        alert(customer.role)

        if(customer.role=="merchant")
        {
          this.router.navigate(['/','product']);
          //alert("userblock")
        }
        else
        {
          this.router.navigate(['/','home']);
          //alert("merchantblock")
        }
        //this.cs.loginStatus().subscribe();
        //this.router.navigate(['/home']);
      }
      else
      {
        localStorage.setItem("customer",JSON.stringify(null));
      }

      // this.cs.getStatus();
    });
  }

}
