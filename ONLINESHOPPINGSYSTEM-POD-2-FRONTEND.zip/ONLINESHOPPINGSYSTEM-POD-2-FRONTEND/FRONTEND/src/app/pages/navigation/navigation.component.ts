import { Component, DoCheck, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../../customer';
import { CustomerService } from '../../customer.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit, DoCheck {
status:string='login';
// customername:string='';
// customer:Customer= new Customer;
customer:any;
fName:any;

  constructor(private cs:CustomerService, private ar:ActivatedRoute, private router:Router) { }

  ngDoCheck(): void {
    this.cs.loginStatus().subscribe((data)=>{
      if(data==null)
      { 

        this.status="login";
      
      }
        else
      {
        this.status="logout";
        var customer = new Customer;
        var customer1 = localStorage.getItem("customer");
        if(customer1){
          customer=JSON.parse(customer1);

        }
          this.fName= customer.firstName;
        
      } 
    });
 
  }

  ngOnInit(): void {

  }

}
