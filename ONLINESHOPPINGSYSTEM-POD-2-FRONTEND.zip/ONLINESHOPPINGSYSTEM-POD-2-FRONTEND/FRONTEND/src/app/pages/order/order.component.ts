import { Component, OnInit } from '@angular/core';
import { Cart } from 'src/app/cart';
import { CartService } from 'src/app/cart.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
    cartItems:any;
    customer:any;
    constructor(private cartService:CartService) { }
    ngDoCheck(): void {
      
      
    }
  
    ngOnInit(): void {
      var c=localStorage.getItem("customer");
      if(c==null || c=='')
      {
        alert('You have not logged in....');
        return;
      }
      //logged in user....
      this.customer=JSON.parse(c);
       var  cartsPrice  = new Cart();
      this.cartService.getCartItemsByCustomerId(this.customer.id).subscribe((data)=>{
        console.log(data);
        this.cartItems=data;
        // alert(JSON.stringify(this.cartItems));
      });
    }
  
    fnRemove(id:any)
    {
        // alert("Removing "+id);
        this.cartService.removeFromCart(id).subscribe((data)=>{
          console.log(data);
        })
    }
  
    
  
  
  }
  