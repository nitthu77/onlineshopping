package com.OnlineShopping.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.OnlineShopping.entity.Customer;
import com.OnlineShopping.entity.Product;

@Repository
public interface ProductDao {

	int create(Product product);
	

	List<Product> read();

	Product read(Long id);
	
	Product read(String category);

	int update(Product product);

	int delete(Long id);

	public List<Product> findProductsByCategory(String category);
		
	public List<String> getCategories();
	
	public List<String> getAllBooks();
	
	public List<String> getAllClothings();
	
	
}

