package com.OnlineShopping.entity;

import java.util.Date;

public class Order {

	private Long orderId;
	private Date orderDate;
	private Long product_Id;
	private Long customer_Id;
	private Long quantity;
	
	public Order() {}

	public Order(Long orderId, Date orderDate, Long product_Id, Long customer_Id, Long quantity) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.product_Id = product_Id;
		this.customer_Id = customer_Id;
		this.quantity = quantity;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Long getProduct_Id() {
		return product_Id;
	}

	public void setProduct_Id(Long product_Id) {
		this.product_Id = product_Id;
	}

	public Long getCustomer_Id() {
		return customer_Id;
	}

	public void setCustomer_Id(Long customer_Id) {
		this.customer_Id = customer_Id;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + orderDate + ", product_Id=" + product_Id
				+ ", customer_Id=" + customer_Id + ", quantity=" + quantity + "]";
	}
	
	
	
}
