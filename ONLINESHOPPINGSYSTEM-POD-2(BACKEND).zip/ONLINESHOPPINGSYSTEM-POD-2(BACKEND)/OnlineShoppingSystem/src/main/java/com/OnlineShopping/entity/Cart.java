package com.OnlineShopping.entity;

public class Cart {
	private Long id;
	private Long productId;
	private Long customerId;
	private Long price;
	
	public Cart() {}

	public Cart(Long id, Long productId, Long customerId, Long price) {
		super();
		this.id = id;
		this.productId = productId;
		this.customerId = customerId;
		this.price = price;
	}
	public Cart(Long id, Long productId, Long customerId) {
		super();
		this.id = id;
		this.productId = productId;
		this.customerId = customerId;
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Cart [id=" + id + ", productId=" + productId + ", customerId=" + customerId + ", price=" + price + "]";
	}


	
			}